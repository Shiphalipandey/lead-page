function openNavbar() { 
	document.getElementById("sideNavigationBar") 
		.style.width = "50%"; 
} 
function closeNavbar() { 
	document.getElementById("sideNavigationBar") 
		.style.width = "0%"; 
}
